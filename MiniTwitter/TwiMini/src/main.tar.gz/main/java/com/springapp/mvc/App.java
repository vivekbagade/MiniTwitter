package com.springapp.mvc;



/**
 * Created with IntelliJ IDEA.
 * User: vivek
 * Date: 7/31/13
 * Time: 2:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class App {
    public void start() throws Exception {
     /*   AnnotationConfigWebApplicationContext appContext = new AnnotationConfigWebApplicationContext();
        appContext.setConfigLocation(AppConfig.class.getName());

        Server server = new Server(8080);
        ServletContextHandler root = new ServletContextHandler(server, "/");
        ServletHolder dispatcherServlet = new ServletHolder(new DispatcherServlet(appContext));
        dispatcherServlet.setInitOrder(1);

        root.addServlet(dispatcherServlet, "/*");



        server.start();*/
    }

    public static void main(String ars[]) throws Exception
    {
        App app=new App();
        app.start();
    }
}
